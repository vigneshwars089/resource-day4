var app=angular.module('App', ['ngMaterial','ngAnimate','angular-venn','ngMessages']);
// var app1=angular.module('main'['ui.router'])
// app1.config(function($stateProvider,$urlRouterProvider) {
//
//
//
//
//     $urlRouterProvider.otherwise('/login');
//
//     $stateProvider
//         .state('login', {
//             url: '/login',
//             templateUrl: '../views/login.html'
//           })
//          .state('home.RFP', {
//            url: '/RFP',
//             templateUrl: '../views/landing.html'
//           })
//         .state('home.DI', {
//           url: '/DI',
//            templateUrl: '../views/DI.html'
//          })
//         .state('home.Demo', {
//          url: '/Demo',
//           templateUrl: '../views/Demo.html'
//           })
//         .state('home.Prototype', {
//           url: '/Prototype',
//           templateUrl: '../views/Prototype.html'
//           })
//         .state('home.RequirementGathering', {
//           url: '/RequirementGathering',
//           templateUrl: '../views/RequirementGathering.html'
//           })
//         .state('home.CostShared', {
//           url: '/CostShared',
//           templateUrl: '../views/CostShared.html'
//         })
//         .state('home.AllocationDone', {
//          url: '/AllocationDone',
//          templateUrl: '../views/AllocationDone.html'
//         })
//        .state('home.AllRFP', {
//         url: '/AllRFP',
//         templateUrl: '../views/Dashboard.html'
//         })
//         .state('home.AllPrototype', {
//          url: '/AllPrototype',
//          templateUrl: '../views/AllPrototype.html'
//          })
//     .state('home.InProgress', {
//      url: '/InProgress',
//      templateUrl: '../views/InProgress.html'
//    })
//    .state('home.Submitted', {
//     url: '/Submitted',
//     templateUrl: '../views/Submitted.html'
//   })
//  .state('home.Won', {
//   url: '/Won',
//   templateUrl: '../views/Won.html'
// })
// .state('home.Lost', {
//  url: '/Lost',
//  templateUrl: '../views/Lost.html'
// })
// .state('home.OnHold', {
//  url: '/OnHold',
//  templateUrl: '../views/OnHold.html'
// })
// // .state('home.OnHold', {
// //  url: '/OnHold',
// //  templateUrl: '../views/OnHold.html'
// // })
// .state('home.Developement', {
//  url: '/Developement',
//  templateUrl: '../views/PDevelopement.html'
// })
// .state('home.Accepted', {
//  url: '/Accepted',
//  templateUrl: '../views/PAccepted.html'
// })
// .state('home.Rejected', {
//  url: '/Rejected',
//  templateUrl: '../views/PRejected.html'
// })
// // .state('home.OnHold', {
// //  url: '/OnHold',
// //  templateUrl: '../views/OnHold.html'
// // })
// .state('home.createpage', {
//  url: '/createpage',
//  templateUrl: '../views/createpage.html'
// })

// });

app.controller('demoController', function($scope) {
	console.log("SDLbnkasdkb");
	$scope.myStyle="width:'200px';background:red";
	$scope.vennData = [
		{sets: ['Head Count'], size: 70},
		{sets: ['Billable Allocation'], size: 20},
		{sets: ['SGA'], size: 10},
		{sets: ['Non-Billable Allocation'], size: 10},
		 {sets: ['Head Count','Billable Allocation'], size: 20},
		 {sets: ['Head Count','SGA'], size: 30},
		 {sets: ['Head Count','Non-Billable Allocation'], size: 20},
		//  {sets: ['Head Count','Billable Allocation', 'SGA'], size: 1},
	];
	// $scope.venn.width

});



app.controller('SearchCtrl', Autosearch);

  function Autosearch ($timeout, $q) {
    var self = this;

    // list of `state` value/display objects
    self.states        = loadAll();
    self.selectedItem  = null;
    self.searchText    = null;
    self.querySearch   = querySearch;

    // ******************************
    // Internal methods
    // ******************************

    /**
     * Search for states... use $timeout to simulate
     * remote dataservice call.
     */
    function querySearch (query) {
      var results = query ? self.states.filter( createFilterFor(query) ) : self.states;
      var deferred = $q.defer();
      $timeout(function () { deferred.resolve( results ); }, Math.random() * 1000, false);
      return deferred.promise;
    }

    /**
     * Build `states` list of key/value pairs
     */
    function loadAll() {
      var allStates = 'Alabama, Alaska, Arizona, Arkansas, California, Colorado, Connecticut, Delaware,\
              Florida, Georgia, Hawaii, Idaho, Illinois, Indiana, Iowa, Kansas, Kentucky, Louisiana,\
              Maine, Maryland, Massachusetts, Michigan, Minnesota, Mississippi, Missouri, Montana,\
              Nebraska, Nevada, New Hampshire, New Jersey, New Mexico, New York, North Carolina,\
              North Dakota, Ohio, Oklahoma, Oregon, Pennsylvania, Rhode Island, South Carolina,\
              South Dakota, Tennessee, Texas, Utah, Vermont, Virginia, Washington, West Virginia,\
              Wisconsin, Wyoming';

      return allStates.split(/, +/g).map( function (state) {
        return {
          value: state.toLowerCase(),
          display: state
        };
      });
    }

    /**
     * Create filter function for a query string
     */
    function createFilterFor(query) {
      var lowercaseQuery = angular.lowercase(query);

      return function filterFn(state) {
        return (state.value.indexOf(lowercaseQuery) === 0);
      };

    }
  }


// app.controller('mainController',function($scope,$state,$mdDialog){
//   $scope.test="hi";
//   $scope.toggler=false;
//   // $scope.main="./views/RFP.html";
//   $scope.sample=function(data){
//     if(!$scope.$$phase) {
//      $scope.$apply(function () {
//
//          $scope.main="./views/"+data+".html";
//      });
//    }else{
//         $scope.main="./views/"+data+".html";
//    }
//
//   }
//   $scope.leave=function() {
//     $state.go('home');
//   }
//
// $scope.RFP=function(data)
// {
//   $state.go('home.'+data);
// }
// $scope.Prototype=function(data)
// {
//   $state.go('home.'+data);
// }
// $scope.close=function()
// {
//   $mdDialog.hide();
// }
//
// $scope.All=function(data)
// {
//   $state.go('home.'+data);
// }
//
// $scope.create =function()
// {
//   $state.go('home.createpage');
//   $mdDialog.show({
//      controller: 'mainController',
//      templateUrl: '../views/createpage.html',
//      parent: angular.element(document.body),
//     //  targetEvent: ev,
//      clickOutsideToClose:true,
//      fullscreen: $scope.customFullscreen // Only for -xs, -sm breakpoints.
//    })
//    .then(function(answer) {
//      $scope.status = 'You said the information was "' + answer + '".';
//    }, function() {
//      $scope.status = 'You cancelled the dialog.';
//    });
//  };
//
//   $scope.Nav=function(toggle){
//     console.log(toggle);
//     if(toggle==true){
//       document.getElementById("mySidenav").style.width = "250px";
//       document.getElementById("sideArrow").style ="margin-left:250px;";
//       document.getElementById("sideArrow").innerHTML='&#8810';
//     }else{
//       document.getElementById("mySidenav").style.width = "0";
//       document.getElementById("sideArrow").style ="margin-left:0px";
//       document.getElementById("sideArrow").innerHTML='&#8811';
//     }
//
//   }
// })
